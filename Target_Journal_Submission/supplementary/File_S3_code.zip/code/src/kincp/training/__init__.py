"""kincp.training"""
